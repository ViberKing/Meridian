// Line-icon set — 24px grid, stroked with currentColor.
const S = (body, vb = '0 0 24 24') =>
  `<svg viewBox="${vb}" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">${body}</svg>`;

export const ICONS = {
  swim: S('<circle cx="16.5" cy="6" r="2"/><path d="M3 12.5l6.5-4 4 3.5 3-2"/><path d="M2.5 18q4.75-3.4 9.5 0t9.5 0"/>'),
  calendar: S('<rect x="3" y="4.5" width="18" height="16" rx="3"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/>'),
  house: S('<path d="M4 10.5 12 4l8 6.5V19a1.5 1.5 0 0 1-1.5 1.5h-13A1.5 1.5 0 0 1 4 19Z"/><path d="M9.5 20.5v-6h5v6"/>'),
  wallet: S('<rect x="3" y="6" width="18" height="14" rx="3"/><path d="M3 10h18M16.5 15h.5"/>'),
  pulse: S('<path d="M3 12h4l2.5-6 4 12L16 12h5"/>'),
  book: S('<path d="M5 4.5A2.5 2.5 0 0 1 7.5 2H19v17.5H7.5A2.5 2.5 0 0 0 5 22Z"/><path d="M5 19.5V4.5M9 6.5h6"/>'),
  wave: S('<path d="M2.5 9q4.75-3.4 9.5 0t9.5 0"/><path d="M2.5 15q4.75-3.4 9.5 0t9.5 0"/>'),
  log: S('<path d="M5 3.5h11.5A2.5 2.5 0 0 1 19 6v14.5l-3.5-2.3-3.5 2.3-3.5-2.3L5 20.5V6a2.5 2.5 0 0 1 0-2.5z"/><path d="M9 8.5h6M9 12h4"/>'),
  ticket: S('<path d="M3 9V7a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v2a3 3 0 0 0 0 6v2a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2v-2a3 3 0 0 0 0-6Z"/><path d="M14 5v2.5M14 11v2.5M14 17v2"/>'),
  person: S('<circle cx="12" cy="7.5" r="3.5"/><path d="M4.5 20.5a7.5 7.5 0 0 1 15 0"/>'),
  pencil: S('<path d="M4 20l1-4L16.5 4.5a2.1 2.1 0 0 1 3 3L8 19l-4 1Z"/><path d="M14.5 6.5l3 3"/>'),
  download: S('<path d="M12 4v10m0 0 4-4m-4 4-4-4"/><path d="M4.5 17v1.5A1.5 1.5 0 0 0 6 20h12a1.5 1.5 0 0 0 1.5-1.5V17"/>'),
  upload: S('<path d="M12 14V4m0 0 4 4m-4-4-4 4"/><path d="M4.5 17v1.5A1.5 1.5 0 0 0 6 20h12a1.5 1.5 0 0 0 1.5-1.5V17"/>'),
  check: S('<path d="M4.5 12.5 10 18 19.5 6.5"/>'),
  plus: S('<path d="M12 5v14M5 12h14"/>'),
  close: S('<path d="M6 6l12 12M18 6 6 18"/>'),
  chevronL: S('<path d="M14.5 5.5 8 12l6.5 6.5"/>'),
  chevronR: S('<path d="M9.5 5.5 16 12l-6.5 6.5"/>'),
  arrowR: S('<path d="M4.5 12h15m0 0-6-6m6 6-6 6"/>'),
};

// The Harbour mark — three swim lanes. `accent` colours the middle lane.
export function mark(size = 28, accent = '#0e8da6', ink = 'currentColor') {
  const span = document.createElement('span');
  span.className = 'mark';
  span.setAttribute('aria-hidden', 'true');
  span.innerHTML = `<svg width="${size}" height="${size}" viewBox="0 0 28 28">
    <rect x="3" y="4.5" width="13" height="5" rx="2.5" fill="${ink}"/>
    <rect x="3" y="11.5" width="22" height="5" rx="2.5" fill="${accent}"/>
    <rect x="3" y="18.5" width="17" height="5" rx="2.5" fill="${ink}"/>
  </svg>`;
  return span;
}

export function icon(name, cls = '') {
  const span = document.createElement('span');
  span.className = ('icon ' + cls).trim();
  span.innerHTML = ICONS[name] || '';
  span.setAttribute('aria-hidden', 'true');
  return span;
}
