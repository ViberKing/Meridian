// Initial data, migrated from the Swim Coaching Tracker spreadsheet.
// Loaded once on first run; after that everything lives in localStorage.

export const SEED = {
  settings: {
    coachName: 'Coach',
    sessionTypes: [
      { id: 'solo30', label: '1:1 · 30 min', price: 20, keep: 15 },
      { id: 'duo30',  label: '2:1 · 30 min', price: 30, keep: 22.5 },
      { id: 'solo60', label: '1:1 · 1 hour', price: 40, keep: 30 },
      { id: 'duo60',  label: '2:1 · 1 hour', price: 60, keep: 45 },
    ],
    block: { price: 100, lessons: 6, keep: 75 },
    dayStart: '07:00',
    dayEnd: '21:00',
  },

  swimmers: [
    { id: 's1', name: 'Sophie L', contact: 'Leah Liennard', email: 'leah_stokes30@hotmail.com',
      usual: 'solo30', notes: 'Comes consistently. Pays £20 per session, I keep £15.' },
    { id: 's2', name: 'AJ', contact: '(Adult)', email: 'aaronmallen@outlook.com',
      usual: 'solo30', notes: 'Comes consistently. Looking to double up sessions.' },
    { id: 's3', name: 'Henry L', contact: 'Hannah Lancaster', email: 'hannahlancaster83@hotmail.com',
      usual: 'solo60', notes: 'Comes very consistently. Pays £40 per session, I keep £30.' },
    { id: 's4', name: 'Andy F', contact: '(Adult)', email: 'andy@raisearchitects.com',
      usual: 'solo30', notes: 'Comes inconsistently. £20, I keep £15.' },
    { id: 's5', name: 'Woodfords', contact: 'Jan Woodford', email: 'janwoodford89@gmail.com',
      usual: 'duo30', notes: 'Trial sessions — may become consistent.' },
    { id: 's6', name: 'Charmaine', contact: 'Charmaine Bruijns', email: 'charmaine.bruijns@gmail.com',
      usual: 'solo30', notes: 'Trial session. Has SEN needs.' },
  ],

  // Block bookings: 5 weeks + 1 free = 6 lessons. Income is recorded here on
  // the start date, so linked lessons in the log carry £0 (no double counting).
  blocks: [
    { id: 'b1', swimmerId: 's2', start: '2026-07-16', price: 100, keep: 75, paid: true,
      notes: 'End date 21/08/2026' },
    { id: 'b2', swimmerId: 's1', start: '2026-07-10', price: 100, keep: 75, paid: true,
      notes: 'End date 27/08/2026' },
  ],

  // status: paid | due | block (prepaid via a block) | free | cancelled
  bookings: [
    // ---- July 2026 ----
    { id: 'bk01', date: '2026-07-03', time: '16:30', swimmerId: 's3', type: 'solo60', price: 40, keep: 30, status: 'paid',  notes: '' },
    { id: 'bk02', date: '2026-07-10', time: '15:00', swimmerId: 's1', type: 'solo30', price: 0,  keep: 0,  status: 'block', blockId: 'b2', notes: 'Block session 1' },
    { id: 'bk03', date: '2026-07-16', time: '17:00', swimmerId: 's2', type: 'solo30', price: 0,  keep: 0,  status: 'block', blockId: 'b1', notes: 'Block session 1' },
    { id: 'bk04', date: '2026-07-16', time: '17:30', swimmerId: 's3', type: 'solo30', price: 20, keep: 15, status: 'paid',  notes: '' },
    { id: 'bk05', date: '2026-07-17', time: '15:00', swimmerId: 's1', type: 'solo30', price: 0,  keep: 0,  status: 'block', blockId: 'b2', notes: 'Block session 2' },
    { id: 'bk06', date: '2026-07-20', time: '15:30', swimmerId: 's2', type: 'solo30', price: 0,  keep: 0,  status: 'block', blockId: 'b1', notes: 'Block session 2' },
    { id: 'bk07', date: '2026-07-23', time: '17:00', swimmerId: 's2', type: 'solo30', price: 0,  keep: 0,  status: 'cancelled', blockId: 'b1', notes: 'Sickness' },
    { id: 'bk08', date: '2026-07-24', time: '15:00', swimmerId: 's1', type: 'solo30', price: 0,  keep: 0,  status: 'block', blockId: 'b2', notes: 'Block session 3' },
    { id: 'bk09', date: '2026-07-24', time: '16:30', swimmerId: 's3', type: 'solo60', price: 40, keep: 30, status: 'paid',  notes: '' },
    { id: 'bk10', date: '2026-07-24', time: '18:00', swimmerId: 's4', type: 'solo30', price: 0,  keep: 0,  status: 'free',  notes: 'Potential end of block' },
    { id: 'bk11', date: '2026-07-31', time: '15:00', swimmerId: 's1', type: 'solo30', price: 0,  keep: 0,  status: 'block', blockId: 'b2', notes: 'Block session 4' },
    { id: 'bk12', date: '2026-07-31', time: '15:30', swimmerId: 's5', type: 'duo30',  price: 30, keep: 22.5, status: 'paid', notes: '' },
    { id: 'bk13', date: '2026-07-31', time: '16:30', swimmerId: 's3', type: 'solo60', price: 40, keep: 30, status: 'paid',  notes: '' },
    // ---- August 2026 ----
    { id: 'bk14', date: '2026-08-03', time: '15:30', swimmerId: 's2', type: 'solo30', price: 0,  keep: 0,  status: 'cancelled', blockId: 'b1', notes: 'Sickness' },
    { id: 'bk15', date: '2026-08-06', time: '17:00', swimmerId: 's2', type: 'solo30', price: 0,  keep: 0,  status: 'cancelled', blockId: 'b1', notes: 'Sickness' },
    { id: 'bk16', date: '2026-08-07', time: '15:00', swimmerId: 's1', type: 'solo30', price: 0,  keep: 0,  status: 'block', blockId: 'b2', notes: 'Block session 5' },
    { id: 'bk17', date: '2026-08-07', time: '15:30', swimmerId: 's5', type: 'duo30',  price: 30, keep: 22.5, status: 'due', notes: '' },
    { id: 'bk18', date: '2026-08-07', time: '16:30', swimmerId: 's3', type: 'solo60', price: 40, keep: 30, status: 'due', notes: '' },
    { id: 'bk19', date: '2026-08-07', time: '18:00', swimmerId: 's4', type: 'solo30', price: 0,  keep: 0,  status: 'free', notes: 'Potential end of block' },
  ],

  // Weekly availability — keyed by real date, then by slot start time.
  // status: available | blocked | booked (label carries the name shown on the grid)
  calendar: {
    '2026-08-03': { '15:30': { status: 'booked', label: 'AJ' }, '16:00': { status: 'booked', label: 'Charmaine' } },
    '2026-08-06': { '17:00': { status: 'booked', label: 'AJ ×2' }, '17:30': { status: 'available' } },
    '2026-08-07': {
      '15:00': { status: 'booked', label: 'Sophie' },
      '15:30': { status: 'booked', label: 'Woodfords' },
      '16:00': { status: 'available' },
      '16:30': { status: 'booked', label: 'Henry 1h' },
      '17:00': { status: 'booked', label: 'Henry 1h' },
      '18:00': { status: 'booked', label: 'Andy F' },
      '18:30': { status: 'available' },
    },
  },
};
