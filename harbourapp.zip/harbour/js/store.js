// State, persistence, and all derived calculations for the Swim module.
import { SEED } from './seed.js';

const KEY = 'harbour.swim.v1';

/* ---------------------------------- state --------------------------------- */

function clone(x) { return JSON.parse(JSON.stringify(x)); }

function loadState() {
  try {
    const raw = localStorage.getItem(KEY);
    if (raw) {
      const s = JSON.parse(raw);
      if (s && s.settings && Array.isArray(s.bookings)) return s;
    }
  } catch (e) { /* corrupted storage falls through to seed */ }
  return clone(SEED);
}

export const state = loadState();

let saveTimer = null;
export function save() {
  clearTimeout(saveTimer);
  saveTimer = setTimeout(() => {
    try { localStorage.setItem(KEY, JSON.stringify(state)); } catch (e) { /* storage full */ }
  }, 120);
}

export function resetToSeed() {
  localStorage.removeItem(KEY);
  Object.keys(state).forEach(k => delete state[k]);
  Object.assign(state, clone(SEED));
  save();
}

export function exportJSON() {
  return JSON.stringify(state, null, 2);
}

export function importJSON(text) {
  const s = JSON.parse(text);
  if (!s || !s.settings || !Array.isArray(s.bookings)) throw new Error('Not a Harbour backup file');
  Object.keys(state).forEach(k => delete state[k]);
  Object.assign(state, s);
  save();
}

export function uid(prefix = 'id') {
  return prefix + '_' + (crypto.randomUUID ? crypto.randomUUID().slice(0, 8) : Math.random().toString(36).slice(2, 10));
}

/* ---------------------------------- dates --------------------------------- */

export function todayISO() {
  const d = new Date();
  return toISO(d);
}
export function toISO(d) {
  return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
}
export function fromISO(iso) {
  const [y, m, d] = iso.split('-').map(Number);
  return new Date(y, m - 1, d);
}
export function mondayOf(iso) {
  const d = fromISO(iso);
  const shift = (d.getDay() + 6) % 7; // Mon=0 … Sun=6
  d.setDate(d.getDate() - shift);
  return toISO(d);
}
export function addDays(iso, n) {
  const d = fromISO(iso);
  d.setDate(d.getDate() + n);
  return toISO(d);
}
export function fmtDate(iso, opts = { weekday: 'short', day: 'numeric', month: 'short' }) {
  return fromISO(iso).toLocaleDateString('en-GB', opts);
}
export function monthName(i) {
  return ['January','February','March','April','May','June','July','August','September','October','November','December'][i];
}

/* ---------------------------------- money --------------------------------- */

export function fmtMoney(n) {
  if (n == null || isNaN(n)) return '£0';
  const v = Math.round(n * 100) / 100;
  return '£' + (Number.isInteger(v) ? v.toLocaleString('en-GB') : v.toLocaleString('en-GB', { minimumFractionDigits: 2 }));
}

/* --------------------------------- lookups -------------------------------- */

export function sessionType(id) {
  return state.settings.sessionTypes.find(t => t.id === id) || null;
}
export function swimmer(id) {
  return state.swimmers.find(s => s.id === id) || null;
}
export function swimmerName(id) {
  const s = swimmer(id);
  return s ? s.name : 'Unknown';
}
export function block(id) {
  return state.blocks.find(b => b.id === id) || null;
}

/* ------------------------------- derived data ------------------------------ */

export const COUNTS_AS_LESSON = st => st !== 'cancelled';
export const CARRIES_INCOME = st => st === 'paid' || st === 'due';

// Earnings between two ISO dates inclusive. Block purchases count on their
// start date; block/free/cancelled lessons carry £0.
export function earnings(fromIso, toIso) {
  let lessons = 0, income = 0, keep = 0;
  for (const b of state.bookings) {
    if (b.date < fromIso || b.date > toIso) continue;
    if (COUNTS_AS_LESSON(b.status)) lessons++;
    if (CARRIES_INCOME(b.status)) { income += b.price || 0; keep += b.keep || 0; }
  }
  for (const bl of state.blocks) {
    if (bl.start && bl.start >= fromIso && bl.start <= toIso) {
      income += bl.price || 0; keep += bl.keep || 0;
    }
  }
  return { lessons, income, keep };
}

export function statTiles() {
  const today = todayISO();
  const weekStart = mondayOf(today);
  const weekEnd = addDays(weekStart, 6);
  const y = today.slice(0, 4), m = today.slice(5, 7);
  const monthStart = `${y}-${m}-01`;
  const monthEnd = `${y}-${m}-31`;
  return {
    week: earnings(weekStart, weekEnd),
    month: earnings(monthStart, monthEnd),
    all: earnings('0000-01-01', '9999-12-31'),
  };
}

export function monthlySeries(year) {
  const out = Array.from({ length: 12 }, () => ({ income: 0, keep: 0, lessons: 0 }));
  for (const b of state.bookings) {
    if (b.date.slice(0, 4) !== String(year)) continue;
    const i = Number(b.date.slice(5, 7)) - 1;
    if (COUNTS_AS_LESSON(b.status)) out[i].lessons++;
    if (CARRIES_INCOME(b.status)) { out[i].income += b.price || 0; out[i].keep += b.keep || 0; }
  }
  for (const bl of state.blocks) {
    if (!bl.start || bl.start.slice(0, 4) !== String(year)) continue;
    const i = Number(bl.start.slice(5, 7)) - 1;
    out[i].income += bl.price || 0; out[i].keep += bl.keep || 0;
  }
  return out;
}

export function blockUsage(blockId) {
  const today = todayISO();
  const total = state.settings.block.lessons;
  const linked = state.bookings.filter(b => b.blockId === blockId && b.status !== 'cancelled');
  const used = linked.filter(b => b.date <= today).length;
  const scheduled = linked.filter(b => b.date > today).length;
  return { used, scheduled, total, left: Math.max(0, total - used) };
}

export function swimmerStats(swimmerId) {
  let lessons = 0, paidTotal = 0;
  for (const b of state.bookings) {
    if (b.swimmerId !== swimmerId) continue;
    if (COUNTS_AS_LESSON(b.status)) lessons++;
    if (b.status === 'paid') paidTotal += b.price || 0;
  }
  for (const bl of state.blocks) {
    if (bl.swimmerId === swimmerId && bl.paid) paidTotal += bl.price || 0;
  }
  return { lessons, paidTotal };
}

export function activeBlockFor(swimmerId) {
  return state.blocks.find(b => b.swimmerId === swimmerId && blockUsage(b.id).left > 0) || null;
}

export function upcomingBookings(limit = 5) {
  const today = todayISO();
  return state.bookings
    .filter(b => b.date >= today && b.status !== 'cancelled')
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time))
    .slice(0, limit);
}

export function outstandingBookings() {
  const today = todayISO();
  return state.bookings
    .filter(b => b.status === 'due' && b.date <= today)
    .sort((a, b) => (a.date + a.time).localeCompare(b.date + b.time));
}

/* --------------------------------- calendar -------------------------------- */

export function slotTimes() {
  const { dayStart, dayEnd } = state.settings;
  const out = [];
  let [h, m] = dayStart.split(':').map(Number);
  const [eh, em] = dayEnd.split(':').map(Number);
  while (h < eh || (h === eh && m < em)) {
    out.push(String(h).padStart(2, '0') + ':' + String(m).padStart(2, '0'));
    m += 30;
    if (m >= 60) { m = 0; h++; }
  }
  return out;
}

export function getSlot(dateIso, time) {
  return (state.calendar[dateIso] || {})[time] || null;
}

export function setSlot(dateIso, time, value) {
  if (!state.calendar[dateIso]) state.calendar[dateIso] = {};
  if (value == null) {
    delete state.calendar[dateIso][time];
    if (!Object.keys(state.calendar[dateIso]).length) delete state.calendar[dateIso];
  } else {
    state.calendar[dateIso][time] = value;
  }
  save();
}

export function copyWeek(fromMonday, toMonday) {
  for (let i = 0; i < 7; i++) {
    const src = addDays(fromMonday, i);
    const dst = addDays(toMonday, i);
    if (state.calendar[src]) state.calendar[dst] = clone(state.calendar[src]);
  }
  save();
}

/* -------------------------------- mutations -------------------------------- */

export function addBooking(b) { state.bookings.push(b); save(); }
export function deleteBooking(id) {
  const i = state.bookings.findIndex(b => b.id === id);
  if (i >= 0) state.bookings.splice(i, 1);
  save();
}
export function addSwimmer(s) { state.swimmers.push(s); save(); }
export function deleteSwimmer(id) {
  const i = state.swimmers.findIndex(s => s.id === id);
  if (i >= 0) state.swimmers.splice(i, 1);
  save();
}
export function addBlock(b) { state.blocks.push(b); save(); }
export function deleteBlock(id) {
  const i = state.blocks.findIndex(b => b.id === id);
  if (i >= 0) state.blocks.splice(i, 1);
  save();
}
