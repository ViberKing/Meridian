// Settings — prices, block config, backup & restore.
import { el, toast, confirmSheet, field, staggerIn } from '../ui.js';
import { icon } from '../icons.js';
import { state, save, fmtMoney, exportJSON, importJSON, resetToSeed, todayISO } from '../store.js';

export function renderSettings() {
  const page = el('main', { class: 'page' },
    el('a', { class: 'back', href: '#/' }, icon('chevronL'), 'Harbour'),
    el('div', { class: 'page-head' },
      el('h1', { class: 'page-title' }, 'Settings'),
    ),
  );

  const content = el('div', { class: 'list', style: 'gap:14px' },
    pricesCard(),
    blockCard(),
    dataCard(),
    aboutCard(),
  );
  page.append(content);
  staggerIn(content);
  return page;
}

function cardHead(chipIcon, chipTint, title) {
  return el('div', { class: 'row gap', style: 'margin-bottom:12px' },
    el('span', { class: 'title-chip ' + chipTint }, icon(chipIcon)),
    el('h2', { class: 'card-title', style: 'margin:0' }, title),
  );
}

function numberInput(value, onChange) {
  const i = el('input', { class: 'input', type: 'number', step: '0.5', min: '0', value, style: 'max-width:110px; text-align:right' });
  i.addEventListener('change', () => onChange(Number(i.value) || 0));
  return i;
}

function pricesCard() {
  const rows = state.settings.sessionTypes.map(t =>
    el('div', { class: 'list-row', style: 'flex-wrap:wrap' },
      el('div', { class: 'row-title', style: 'flex:1 1 100%' }, t.label),
      el('div', { class: 'row gap' },
        field('Price', numberInput(t.price, v => { t.price = v; save(); toast('Price updated'); })),
        field('You keep', numberInput(t.keep, v => { t.keep = v; save(); toast('Share updated'); })),
      ),
    ));
  return el('section', { class: 'card' },
    cardHead('wallet', 'green', 'Lesson prices'),
    el('div', { class: 'list' }, rows),
  );
}

function blockCard() {
  const cfg = state.settings.block;
  return el('section', { class: 'card' },
    cardHead('ticket', 'aqua', 'Blocks'),
    el('div', { class: 'row gap', style: 'flex-wrap:wrap' },
      field('Price (£)', numberInput(cfg.price, v => { cfg.price = v; save(); toast('Block price updated'); })),
      field('Lessons', numberInput(cfg.lessons, v => { cfg.lessons = Math.max(1, Math.round(v)); save(); toast('Block length updated'); })),
      field('You keep (£)', numberInput(cfg.keep, v => { cfg.keep = v; save(); toast('Block share updated'); })),
    ),
  );
}

function dataCard() {
  const fileIn = el('input', { type: 'file', accept: 'application/json', style: 'display:none' });
  fileIn.addEventListener('change', async () => {
    const f = fileIn.files[0];
    if (!f) return;
    try {
      importJSON(await f.text());
      toast('Backup restored');
      setTimeout(() => location.reload(), 600);
    } catch (e) {
      toast('That file isn’t a Harbour backup');
    }
  });

  return el('section', { class: 'card' },
    cardHead('download', 'violet', 'Data'),
    el('p', { class: 'card-sub' }, 'Stored on this device only.'),
    el('div', { class: 'row gap', style: 'flex-wrap:wrap' },
      el('button', {
        class: 'btn ghost sm',
        onclick: () => {
          const blob = new Blob([exportJSON()], { type: 'application/json' });
          const a = el('a', { href: URL.createObjectURL(blob), download: `harbour-swim-backup-${todayISO()}.json` });
          document.body.append(a); a.click(); a.remove();
          toast('Backup downloaded');
        },
      }, icon('download'), 'Export'),
      el('button', { class: 'btn ghost sm', onclick: () => fileIn.click() }, icon('upload'), 'Restore'),
      el('button', {
        class: 'btn danger sm',
        onclick: async () => {
          if (await confirmSheet('Start fresh?', 'This wipes all swimmers, bookings and blocks on this device and restores the original spreadsheet data.', 'Reset')) {
            resetToSeed();
            toast('Reset to spreadsheet data');
            setTimeout(() => location.reload(), 600);
          }
        },
      }, 'Reset'),
      fileIn,
    ),
  );
}

function aboutCard() {
  return el('section', { class: 'card' },
    cardHead('house', 'blue', 'Install'),
    el('p', { class: 'muted', style: 'margin:6px 0 0' },
      'iPhone: Share → Add to Home Screen. Android / desktop: Install app from the browser menu. Works offline once installed.'),
  );
}
