// Bookings log — one row per lesson, grouped by month, add/edit via sheet.
import { el, openSheet, confirmSheet, toast, field, select, statusPill, staggerIn } from '../ui.js';
import { icon } from '../icons.js';
import {
  state, save, uid, todayISO, fmtDate, fmtMoney, sessionType, swimmerName,
  activeBlockFor, addBooking, deleteBooking, monthName, CARRIES_INCOME,
} from '../store.js';

export function renderBookings() {
  const page = el('main', { class: 'page' },
    el('a', { class: 'back', href: '#/' }, icon('chevronL'), 'Harbour'),
    el('div', { class: 'page-head' },
      el('h1', { class: 'page-title' }, 'Bookings'),
    ),
  );

  const body = el('div', {});
  page.append(body, fab(() => bookingSheet(null, () => draw(body))));
  draw(body);
  return page;
}

function fab(onclick) {
  return el('button', { class: 'fab', 'aria-label': 'Add booking', onclick }, icon('plus'));
}

function draw(body) {
  const groups = new Map(); // 'YYYY-MM' -> bookings
  const sorted = [...state.bookings].sort((a, b) => (b.date + b.time).localeCompare(a.date + a.time));
  for (const b of sorted) {
    const key = b.date.slice(0, 7);
    if (!groups.has(key)) groups.set(key, []);
    groups.get(key).push(b);
  }

  body.replaceChildren();
  if (!groups.size) {
    body.append(el('div', { class: 'empty' },
      icon('log'),
      el('p', {}, 'No lessons yet — tap + to add one.')));
    return;
  }

  for (const [key, items] of groups) {
    const kept = items.reduce((a, b) => a + (CARRIES_INCOME(b.status) ? (b.keep || 0) : 0), 0);
    const blockKeep = state.blocks
      .filter(bl => bl.start && bl.start.slice(0, 7) === key)
      .reduce((a, bl) => a + (bl.keep || 0), 0);
    body.append(el('div', { class: 'month-h' },
      `${monthName(Number(key.slice(5, 7)) - 1)} ${key.slice(0, 4)}`,
      el('span', { class: 'amt' }, `kept ${fmtMoney(kept + blockKeep)}`),
    ));
    const list = el('div', { class: 'list' }, items.map(b => bookingRow(b, body)));
    body.append(list);
    staggerIn(list);
  }
}

function bookingRow(b, body) {
  const t = sessionType(b.type);
  const money = CARRIES_INCOME(b.status)
    ? el('div', { class: 'row-money' }, fmtMoney(b.price), ' ', el('small', {}, `· keep ${fmtMoney(b.keep)}`))
    : null;
  return el('button', {
    class: 'list-row', style: 'text-align:left; width:100%',
    onclick: () => bookingSheet(b, () => draw(body)),
  },
    el('div', { class: 'date-chip' },
      el('div', { class: 'd' }, b.date.slice(8, 10)),
      el('div', { class: 'm' }, fmtDate(b.date, { month: 'short' })),
    ),
    el('div', { class: 'row-main' },
      el('div', { class: 'row-title' }, swimmerName(b.swimmerId)),
      el('div', { class: 'row-sub' }, [b.time, t ? t.label : b.type].filter(Boolean).join(' · ')),
    ),
    el('div', { class: 'row-end' }, money, statusPill(b.status)),
  );
}

/* ------------------------------ add/edit sheet ----------------------------- */

export function bookingSheet(existing, onDone, prefill = {}) {
  const isNew = !existing;
  const b = existing || {
    id: uid('bk'), date: prefill.date || todayISO(), time: prefill.time || '16:00',
    swimmerId: state.swimmers[0]?.id || '', type: state.swimmers[0]?.usual || 'solo30',
    price: 0, keep: 0, status: 'due', notes: '', blockId: undefined,
  };

  const dateIn = el('input', { class: 'input', type: 'date', value: b.date });
  const timeIn = el('input', { class: 'input', type: 'time', value: b.time, step: 60 * 30 });
  const swimmerSel = select(state.swimmers.map(s => ({ value: s.id, label: s.name })), b.swimmerId);
  const typeSel = select(state.settings.sessionTypes.map(t => ({ value: t.id, label: t.label })), b.type);
  const statusSel = select([
    { value: 'paid', label: 'Paid' },
    { value: 'due', label: 'Due (not paid yet)' },
    { value: 'block', label: 'Part of a block (prepaid)' },
    { value: 'free', label: 'Free / comp' },
    { value: 'cancelled', label: 'Cancelled' },
  ], b.status);
  const priceIn = el('input', { class: 'input', type: 'number', step: '0.5', min: '0', value: b.price });
  const keepIn = el('input', { class: 'input', type: 'number', step: '0.5', min: '0', value: b.keep });
  const notesIn = el('input', { class: 'input', type: 'text', value: b.notes || '', placeholder: 'Optional note' });

  function syncPrices() {
    const st = statusSel.value;
    if (st === 'block' || st === 'free' || st === 'cancelled') {
      priceIn.value = 0; keepIn.value = 0;
      priceIn.disabled = keepIn.disabled = true;
    } else {
      priceIn.disabled = keepIn.disabled = false;
      const t = sessionType(typeSel.value);
      if (t) { priceIn.value = t.price; keepIn.value = t.keep; }
    }
  }
  typeSel.addEventListener('change', syncPrices);
  statusSel.addEventListener('change', syncPrices);
  swimmerSel.addEventListener('change', () => {
    const sw = state.swimmers.find(s => s.id === swimmerSel.value);
    if (sw && sw.usual) { typeSel.value = sw.usual; }
    if (activeBlockFor(swimmerSel.value)) statusSel.value = 'block';
    syncPrices();
  });
  if (isNew && !prefill.keepStatus) {
    if (activeBlockFor(b.swimmerId)) statusSel.value = 'block';
    syncPrices();
  }

  const saveBtn = el('button', {
    class: 'btn grow',
    onclick: () => {
      b.date = dateIn.value || todayISO();
      b.time = timeIn.value || '16:00';
      b.swimmerId = swimmerSel.value;
      b.type = typeSel.value;
      b.status = statusSel.value;
      b.price = Number(priceIn.value) || 0;
      b.keep = Number(keepIn.value) || 0;
      b.notes = notesIn.value.trim();
      b.blockId = b.status === 'block' ? (activeBlockFor(b.swimmerId)?.id || b.blockId) : undefined;
      if (isNew) addBooking(b); else save();
      close();
      toast(isNew ? 'Lesson added' : 'Lesson updated');
      onDone();
    },
  }, isNew ? 'Add lesson' : 'Save changes');

  const delBtn = isNew ? null : el('button', {
    class: 'btn danger', 'aria-label': 'Delete booking',
    onclick: async () => {
      if (await confirmSheet('Delete lesson?', `${swimmerName(b.swimmerId)} on ${fmtDate(b.date)} will be removed from the log.`)) {
        deleteBooking(b.id);
        close();
        toast('Lesson deleted');
        onDone();
      }
    },
  }, 'Delete');

  const close = openSheet(isNew ? 'Add lesson' : 'Edit lesson', el('div', {},
    el('div', { class: 'form-grid' },
      field('Date', dateIn), field('Time', timeIn),
      el('div', { class: 'span2' }, field('Swimmer', swimmerSel)),
      field('Session type', typeSel), field('Payment', statusSel),
      field('Price (£)', priceIn), field('You keep (£)', keepIn),
      el('div', { class: 'span2' }, field('Notes', notesIn)),
    ),
    el('div', { class: 'row gap' }, delBtn, saveBtn),
  ));
}
