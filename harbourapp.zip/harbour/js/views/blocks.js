// Block bookings — 5 weeks + 1 free, with progress rings.
import { el, openSheet, confirmSheet, toast, field, select, staggerIn } from '../ui.js';
import { icon } from '../icons.js';
import {
  state, save, uid, todayISO, fmtDate, fmtMoney, swimmerName, blockUsage,
  addBlock, deleteBlock, addBooking,
} from '../store.js';

export function renderBlocks() {
  const cfg = state.settings.block;
  const page = el('main', { class: 'page' },
    el('a', { class: 'back', href: '#/' }, icon('chevronL'), 'Harbour'),
    el('div', { class: 'page-head' },
      el('div', {},
        el('h1', { class: 'page-title' }, 'Blocks'),
        el('p', { class: 'page-sub' }, `${cfg.lessons} lessons · ${fmtMoney(cfg.price)}`),
      ),
    ),
  );
  const body = el('div', {});
  page.append(body, el('button', {
    class: 'fab', 'aria-label': 'Add block',
    onclick: () => blockSheet(null, () => draw(body)),
  }, icon('plus')));
  draw(body);
  return page;
}

function draw(body) {
  body.replaceChildren();
  if (!state.blocks.length) {
    body.append(el('div', { class: 'empty' },
      icon('ticket'),
      el('p', {}, 'No blocks yet — tap + when someone pre-pays.')));
    return;
  }
  const sorted = [...state.blocks].sort((a, b) => (b.start || '').localeCompare(a.start || ''));
  const list = el('div', { class: 'list', style: 'gap:10px' }, sorted.map(b => card(b, body)));
  body.append(list);
  staggerIn(list);
}

function ring(used, total) {
  const R = 26, C = 2 * Math.PI * R;
  const frac = total ? Math.min(1, used / total) : 0;
  return el('div', { class: 'ring-wrap' },
    el('span', {
      html: `<svg width="64" height="64" viewBox="0 0 64 64">
        <circle class="ring-track" cx="32" cy="32" r="${R}" fill="none" stroke-width="6"/>
        <circle class="ring-fill" cx="32" cy="32" r="${R}" fill="none" stroke-width="6"
          stroke-dasharray="${C}" stroke-dashoffset="${C * (1 - frac)}"/>
      </svg>` }),
    el('div', { class: 'ring-label' },
      el('div', { class: 'big' }, `${used}/${total}`),
      el('div', { class: 'sml' }, 'used'),
    ),
  );
}

function card(b, body) {
  const u = blockUsage(b.id);
  const done = u.left === 0;
  return el('div', { class: 'card' },
    el('div', { class: 'row gap' },
      ring(u.used, u.total),
      el('div', { class: 'row-main' },
        el('div', { class: 'row-title' }, swimmerName(b.swimmerId)),
        el('div', { class: 'row-sub' },
          `Started ${b.start ? fmtDate(b.start) : '—'} · ${fmtMoney(b.price)}`),
        el('div', { style: 'margin-top:6px; display:flex; gap:6px; flex-wrap:wrap' },
          el('span', { class: 'pill ' + (b.paid ? 'pill-paid' : 'pill-due') }, b.paid ? 'Paid' : 'Unpaid'),
          done
            ? el('span', { class: 'pill pill-free' }, 'Complete')
            : el('span', { class: 'pill ' + (u.left <= 1 ? 'pill-due' : 'pill-block') }, `${u.left} left${u.scheduled ? ` · ${u.scheduled} scheduled` : ''}`),
        ),
      ),
      el('button', { class: 'icon-btn', 'aria-label': 'Edit block', onclick: () => blockSheet(b, () => draw(body)) }, icon('pencil')),
    ),
    done ? null : el('div', { class: 'row gap', style: 'margin-top:14px' },
      el('button', {
        class: 'btn ghost sm grow',
        onclick: () => {
          addBooking({
            id: uid('bk'), date: todayISO(), time: '16:00', swimmerId: b.swimmerId,
            type: state.swimmers.find(s => s.id === b.swimmerId)?.usual || 'solo30',
            price: 0, keep: 0, status: 'block', blockId: b.id,
            notes: `Block session ${u.used + u.scheduled + 1}`,
          });
          toast('Block lesson logged for today');
          draw(body);
        },
      }, 'Log lesson today'),
    ),
    b.notes ? el('p', { class: 'muted note-clamp', style: 'margin:12px 0 0; font-size:13px' }, b.notes) : null,
  );
}

function blockSheet(existing, onDone) {
  const isNew = !existing;
  const cfg = state.settings.block;
  const b = existing || {
    id: uid('b'), swimmerId: state.swimmers[0]?.id || '', start: todayISO(),
    price: cfg.price, keep: cfg.keep, paid: false, notes: '',
  };

  const swimmerSel = select(state.swimmers.map(s => ({ value: s.id, label: s.name })), b.swimmerId);
  const startIn = el('input', { class: 'input', type: 'date', value: b.start || '' });
  const priceIn = el('input', { class: 'input', type: 'number', step: '0.5', min: '0', value: b.price });
  const keepIn = el('input', { class: 'input', type: 'number', step: '0.5', min: '0', value: b.keep });
  const paidSel = select([{ value: 'yes', label: 'Paid' }, { value: 'no', label: 'Not paid yet' }], b.paid ? 'yes' : 'no');
  const notesIn = el('input', { class: 'input', type: 'text', value: b.notes || '', placeholder: 'e.g. end date' });

  const saveBtn = el('button', {
    class: 'btn grow',
    onclick: () => {
      b.swimmerId = swimmerSel.value;
      b.start = startIn.value || todayISO();
      b.price = Number(priceIn.value) || 0;
      b.keep = Number(keepIn.value) || 0;
      b.paid = paidSel.value === 'yes';
      b.notes = notesIn.value.trim();
      if (isNew) addBlock(b); else save();
      close();
      toast(isNew ? 'Block added' : 'Block updated');
      onDone();
    },
  }, isNew ? 'Add block' : 'Save changes');

  const delBtn = isNew ? null : el('button', {
    class: 'btn danger',
    onclick: async () => {
      if (await confirmSheet('Delete block?', `${swimmerName(b.swimmerId)}’s block will be removed. Linked lessons stay in the log.`)) {
        deleteBlock(b.id);
        close();
        toast('Block deleted');
        onDone();
      }
    },
  }, 'Delete');

  const close = openSheet(isNew ? 'Add block booking' : 'Edit block', el('div', {},
    el('p', { class: 'muted', style: 'margin:0 0 16px' },
      'Money is counted here on the start date — linked lessons in the log carry £0, so nothing is double-counted.'),
    field('Swimmer', swimmerSel),
    el('div', { class: 'form-grid' },
      field('Start date', startIn), field('Payment', paidSel),
      field('Price (£)', priceIn), field('You keep (£)', keepIn),
      el('div', { class: 'span2' }, field('Notes', notesIn)),
    ),
    el('div', { class: 'row gap' }, delBtn, saveBtn),
  ));
}
