// Weekly availability calendar — day list on mobile, full grid on desktop.
import { el, openSheet, toast, field } from '../ui.js';
import { icon } from '../icons.js';
import {
  state, slotTimes, getSlot, setSlot, copyWeek, mondayOf, addDays,
  todayISO, fmtDate, fromISO,
} from '../store.js';

const DAY_NAMES = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
let weekStart = null;   // ISO Monday of the visible week
let selectedDay = null; // ISO date selected in the mobile day-tabs

export function renderCalendar() {
  const today = todayISO();
  if (!weekStart) weekStart = mondayOf(today);
  if (!selectedDay || mondayOf(selectedDay) !== weekStart) {
    selectedDay = mondayOf(today) === weekStart ? today : weekStart;
  }

  const page = el('main', { class: 'page' },
    el('a', { class: 'back', href: '#/' }, icon('chevronL'), 'Harbour'),
    el('div', { class: 'page-head' },
      el('h1', { class: 'page-title' }, 'Calendar'),
    ),
  );

  const body = el('div', {});
  page.append(body);
  draw(body);
  return page;
}

function draw(body) {
  const today = todayISO();
  const weekEnd = addDays(weekStart, 6);
  const isDesktop = window.matchMedia('(min-width: 880px)').matches;

  body.replaceChildren(
    el('div', { class: 'week-nav' },
      el('button', { class: 'icon-btn', 'aria-label': 'Previous week', onclick: () => { weekStart = addDays(weekStart, -7); draw(body); } }, icon('chevronL')),
      el('div', { class: 'label', style: 'text-align:center' },
        `${fmtDate(weekStart, { day: 'numeric', month: 'short' })} – ${fmtDate(weekEnd, { day: 'numeric', month: 'short' })}`,
        el('small', {}, mondayOf(today) === weekStart ? 'This week' : fromISO(weekStart).getFullYear()),
      ),
      el('button', { class: 'icon-btn', 'aria-label': 'Next week', onclick: () => { weekStart = addDays(weekStart, 7); draw(body); } }, icon('chevronR')),
    ),
    isDesktop ? weekGrid(body) : dayView(body),
    el('div', { class: 'legend' },
      el('span', { class: 'k' }, el('span', { class: 'swatch', style: 'background:var(--good-tint); border:1px solid var(--good)' }), 'Available'),
      el('span', { class: 'k' }, el('span', { class: 'swatch', style: 'background:var(--accent-tint); border:1px solid var(--accent)' }), 'Booked'),
      el('span', { class: 'k' }, el('span', { class: 'swatch', style: 'background:var(--surface-3)' }), 'Blocked'),
    ),
    el('div', { class: 'row gap', style: 'margin-top:16px' },
      el('button', { class: 'btn ghost sm', onclick: () => { weekStart = mondayOf(todayISO()); draw(body); } }, 'Today'),
      el('button', {
        class: 'btn ghost sm',
        onclick: () => { copyWeek(addDays(weekStart, -7), weekStart); toast('Copied last week'); draw(body); },
      }, 'Copy last week'),
    ),
  );
}

/* ------------------------------- mobile view ------------------------------- */

function dayView(body) {
  const today = todayISO();
  const tabs = el('div', { class: 'day-tabs', role: 'tablist' },
    DAY_NAMES.map((name, i) => {
      const iso = addDays(weekStart, i);
      const hasSlots = !!state.calendar[iso] && Object.keys(state.calendar[iso]).length > 0;
      return el('button', {
        class: 'day-tab' + (iso === selectedDay ? ' active' : '') + (iso === today ? ' today' : '') + (hasSlots ? ' has-slots' : ''),
        role: 'tab', 'aria-selected': iso === selectedDay ? 'true' : 'false',
        onclick: () => { selectedDay = iso; draw(body); },
      }, name, el('span', { class: 'num' }, iso.slice(8, 10)), el('span', { class: 'dot' }));
    }),
  );

  const list = el('div', { class: 'slot-list' },
    slotTimes().map(time => {
      const slot = getSlot(selectedDay, time);
      const cls = slot ? ` is-${slot.status}` : '';
      const label = !slot ? '—'
        : slot.status === 'booked' ? (slot.label || 'Booked')
        : slot.status === 'available' ? 'Available'
        : 'Blocked';
      return el('button', { class: 'slot' + cls, onclick: () => editSlot(selectedDay, time, () => draw(body)) },
        el('span', { class: 't' }, time),
        el('span', { class: 'what' }, label),
      );
    }),
  );
  return el('div', {}, tabs, list);
}

/* ------------------------------- desktop grid ------------------------------ */

function weekGrid(body) {
  const today = todayISO();
  const grid = el('div', { class: 'week-grid' }, el('div', { class: 'wg-head', style: 'border-left:0' }));
  for (let i = 0; i < 7; i++) {
    const iso = addDays(weekStart, i);
    grid.append(el('div', { class: 'wg-head' + (iso === today ? ' today' : '') },
      DAY_NAMES[i], el('span', { class: 'num' }, iso.slice(8, 10))));
  }
  for (const time of slotTimes()) {
    grid.append(el('div', { class: 'wg-cell wg-time' }, time));
    for (let i = 0; i < 7; i++) {
      const iso = addDays(weekStart, i);
      const slot = getSlot(iso, time);
      const cls = slot ? ` is-${slot.status}` : '';
      const label = slot && slot.status === 'booked' ? (slot.label || 'Booked') : '';
      grid.append(el('div', { class: 'wg-cell' },
        el('button', {
          class: 'wg-slot' + cls,
          title: `${DAY_NAMES[i]} ${time}` + (slot ? ` — ${slot.status}${label ? ': ' + label : ''}` : ''),
          onclick: () => editSlot(iso, time, () => draw(body)),
        }, label),
      ));
    }
  }
  return el('div', { class: 'week-grid-wrap' }, grid);
}

/* ------------------------------- slot editor ------------------------------- */

function editSlot(dateIso, time, onDone) {
  const slot = getSlot(dateIso, time) || {};
  let status = slot.status || 'none';

  const nameInput = el('input', {
    class: 'input', type: 'text', placeholder: 'e.g. Sophie, Henry 1h…',
    value: slot.label || '', list: 'swimmer-names',
  });
  const datalist = el('datalist', { id: 'swimmer-names' },
    state.swimmers.map(s => el('option', { value: s.name })));

  const nameField = field('Who’s booked in?', el('div', {}, nameInput, datalist));
  nameField.style.display = status === 'booked' ? '' : 'none';

  const options = [
    ['none', 'Clear', 'var(--hairline-strong)'],
    ['available', 'Available', '#177e4d'],
    ['booked', 'Booked', '#0e8da6'],
    ['blocked', 'Blocked out', '#9aa7b8'],
  ];
  const seg = el('div', { class: 'list', style: 'gap:6px; margin-bottom:14px' },
    options.map(([value, label, dot]) =>
      el('button', {
        class: 'slot' + (status === value ? ' is-booked' : ''),
        onclick: (e) => {
          status = value;
          [...seg.children].forEach(c => c.classList.remove('is-booked'));
          e.currentTarget.classList.add('is-booked');
          nameField.style.display = value === 'booked' ? '' : 'none';
          if (value === 'booked') nameInput.focus();
        },
      },
        el('span', { class: 'dot-swatch', style: `background:${dot}` }),
        el('span', { class: 'what', style: 'color:var(--ink)' }, label),
      ),
    ),
  );

  const close = openSheet(`${fmtDate(dateIso)} · ${time}`, el('div', {},
    seg,
    nameField,
    el('button', {
      class: 'btn grow', style: 'width:100%',
      onclick: () => {
        if (status === 'none') setSlot(dateIso, time, null);
        else if (status === 'booked') setSlot(dateIso, time, { status, label: nameInput.value.trim() || 'Booked' });
        else setSlot(dateIso, time, { status });
        close();
        onDone();
      },
    }, 'Save slot'),
  ));
}
