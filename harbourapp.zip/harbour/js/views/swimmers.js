// Swimmers — contact cards with live lesson counts and totals.
import { el, openSheet, confirmSheet, toast, field, select, initials, staggerIn } from '../ui.js';
import { icon } from '../icons.js';
import {
  state, save, uid, fmtMoney, sessionType, swimmerStats,
  addSwimmer, deleteSwimmer, activeBlockFor, blockUsage,
} from '../store.js';

export function renderSwimmers() {
  const page = el('main', { class: 'page' },
    el('a', { class: 'back', href: '#/' }, icon('chevronL'), 'Harbour'),
    el('div', { class: 'page-head' },
      el('h1', { class: 'page-title' }, 'Swimmers'),
    ),
  );
  const body = el('div', {});
  page.append(body, el('button', {
    class: 'fab', 'aria-label': 'Add swimmer',
    onclick: () => swimmerSheet(null, () => draw(body)),
  }, icon('plus')));
  draw(body);
  return page;
}

function draw(body) {
  body.replaceChildren();
  if (!state.swimmers.length) {
    body.append(el('div', { class: 'empty' },
      icon('person'),
      el('p', {}, 'No swimmers yet — tap + to add one.')));
    return;
  }
  const grid = el('div', { class: 'grid-2' }, state.swimmers.map((s, i) => card(s, i, body)));
  body.append(grid);
  staggerIn(grid);
}

function card(s, i, body) {
  const stats = swimmerStats(s.id);
  const t = sessionType(s.usual);
  const block = activeBlockFor(s.id);
  return el('button', {
    class: 'card', style: 'text-align:left; cursor:pointer',
    onclick: () => swimmerSheet(s, () => draw(body)),
  },
    el('div', { class: 'row gap' },
      el('div', { class: 'avatar' + (i % 5 ? ' c' + (i % 5 + 1) : '') }, initials(s.name)),
      el('div', { class: 'row-main' },
        el('div', { class: 'row-title' }, s.name),
        el('div', { class: 'row-sub' }, [s.contact, t ? t.label : null].filter(Boolean).join(' · ')),
      ),
      block ? el('span', { class: 'pill pill-block' }, `Block · ${blockUsage(block.id).left} left`) : null,
    ),
    el('div', { class: 'mod-stats' },
      el('div', {}, el('b', {}, String(stats.lessons)), el('span', {}, 'lessons')),
      el('div', {}, el('b', {}, fmtMoney(stats.paidTotal)), el('span', {}, 'total paid')),
    ),
    s.notes ? el('p', { class: 'muted note-clamp', style: 'margin:12px 0 0; font-size:13px' }, s.notes) : null,
  );
}

export function swimmerSheet(existing, onDone) {
  const isNew = !existing;
  const s = existing || { id: uid('s'), name: '', contact: '', email: '', usual: 'solo30', notes: '' };

  const nameIn = el('input', { class: 'input', type: 'text', value: s.name, placeholder: 'Swimmer’s name' });
  const contactIn = el('input', { class: 'input', type: 'text', value: s.contact, placeholder: 'Parent / contact' });
  const emailIn = el('input', { class: 'input', type: 'email', value: s.email, placeholder: 'name@email.com' });
  const usualSel = select(state.settings.sessionTypes.map(t => ({ value: t.id, label: t.label })), s.usual);
  const notesIn = el('textarea', { class: 'input', rows: 3, placeholder: 'Anything worth remembering' });
  notesIn.value = s.notes || '';

  const saveBtn = el('button', {
    class: 'btn grow',
    onclick: () => {
      if (!nameIn.value.trim()) { nameIn.focus(); return; }
      s.name = nameIn.value.trim();
      s.contact = contactIn.value.trim();
      s.email = emailIn.value.trim();
      s.usual = usualSel.value;
      s.notes = notesIn.value.trim();
      if (isNew) addSwimmer(s); else save();
      close();
      toast(isNew ? 'Swimmer added' : 'Swimmer updated');
      onDone();
    },
  }, isNew ? 'Add swimmer' : 'Save changes');

  const delBtn = isNew ? null : el('button', {
    class: 'btn danger',
    onclick: async () => {
      if (await confirmSheet('Remove swimmer?', `${s.name} will be removed. Their logged lessons stay in the bookings log.`)) {
        deleteSwimmer(s.id);
        close();
        toast('Swimmer removed');
        onDone();
      }
    },
  }, 'Remove');

  const close = openSheet(isNew ? 'Add swimmer' : s.name, el('div', {},
    field('Name', nameIn),
    field('Parent / contact', contactIn),
    field('Email', emailIn),
    field('Usual session', usualSel),
    field('Notes', notesIn),
    el('div', { class: 'row gap' }, delBtn, saveBtn),
  ));
}
