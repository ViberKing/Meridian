// Harbour home — brand row, greeting, module cards.
import { el, staggerIn } from '../ui.js';
import { icon, mark } from '../icons.js';
import { statTiles, fmtMoney, upcomingBookings, swimmerName, fmtDate, todayISO } from '../store.js';

function greeting() {
  const h = new Date().getHours();
  if (h < 5) return 'Late night';
  if (h < 12) return 'Good morning';
  if (h < 17) return 'Good afternoon';
  return 'Good evening';
}

export function renderHome() {
  const stats = statTiles();
  const next = upcomingBookings(1)[0];

  const page = el('main', { class: 'page' },
    el('header', { class: 'hero' },
      el('div', { class: 'hero-brand' },
        mark(26, '#0e8da6', '#16283a'),
        el('span', { class: 'wordmark' }, 'harbour'),
      ),
      el('h1', { class: 'hero-greet' }, greeting()),
      el('p', { class: 'hero-sub' }, fmtDate(todayISO(), { weekday: 'long', day: 'numeric', month: 'long' })),
    ),
  );

  const grid = el('div', { class: 'mod-grid' },
    el('a', { class: 'mod live', href: '#/swim' },
      el('span', { class: 'mod-open' }, icon('arrowR')),
      el('div', { class: 'mod-icon' }, icon('swim')),
      el('div', { class: 'mod-name' }, 'Swim Coaching'),
      el('div', { class: 'mod-desc' }, next
        ? `Next: ${swimmerName(next.swimmerId)} · ${fmtDate(next.date)}, ${next.time}`
        : 'Lessons, swimmers and earnings.'),
      el('div', { class: 'mod-stats' },
        el('div', {}, el('b', {}, String(stats.week.lessons)), el('span', {}, 'this week')),
        el('div', {}, el('b', {}, fmtMoney(stats.month.keep)), el('span', {}, 'month')),
        el('div', {}, el('b', {}, fmtMoney(stats.all.keep)), el('span', {}, 'all time')),
      ),
    ),
    soon('house', 'Property', 'amber'),
    soon('wallet', 'Money', 'green'),
    soon('pulse', 'Fitness', 'coral'),
    soon('book', 'Journal', 'violet'),
  );
  page.append(grid);
  staggerIn(grid);
  return page;
}

function soon(ic, name, tint) {
  return el('div', { class: `mod soon tint-${tint}` },
    el('span', { class: 'mod-soon' }, 'Soon'),
    el('div', { class: 'mod-icon' }, icon(ic)),
    el('div', { class: 'mod-name' }, name),
  );
}
