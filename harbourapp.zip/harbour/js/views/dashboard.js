// Swim dashboard — one stats card with a period switch, chart, what's next.
import { el, countUp, staggerIn, statusPill } from '../ui.js';
import { icon } from '../icons.js';
import {
  statTiles, fmtMoney, monthlySeries, monthName, upcomingBookings,
  outstandingBookings, swimmerName, sessionType, fmtDate, state, blockUsage,
} from '../store.js';

// Chart series — validated with the dataviz palette checker against #ffffff.
const C_KEEP = '#2456a6';   // you keep
const C_POOL = '#0e8da6';   // pool's share

export function renderDashboard() {
  const page = el('main', { class: 'page' },
    el('a', { class: 'back', href: '#/' }, icon('chevronL'), 'Harbour'),
    el('div', { class: 'page-head' },
      el('h1', { class: 'page-title' }, 'Dashboard'),
    ),
  );

  const content = el('div', { class: 'list', style: 'gap:14px' },
    statsCard(),
    chartCard(),
    owedCard(),
    upcomingCard(),
    blocksCard(),
  );
  page.append(content);
  staggerIn(content);
  return page;
}

/* -------------------------------- stats card ------------------------------- */

function statsCard() {
  const s = statTiles();
  const periods = [['week', 'Week', s.week], ['month', 'Month', s.month], ['all', 'All time', s.all]];

  const keep = el('div', { class: 'hero-num' });
  const lessons = el('b', {});
  const income = el('b', {});

  function show(key) {
    const e = periods.find(p => p[0] === key)[2];
    [...seg.children].forEach(b => b.classList.toggle('active', b.dataset.k === key));
    countUp(keep, e.keep, v => fmtMoney(Math.round(v * 2) / 2), 450);
    countUp(lessons, e.lessons, v => String(Math.round(v)), 450);
    countUp(income, e.income, v => fmtMoney(Math.round(v)), 450);
  }

  const seg = el('div', { class: 'seg on-dark' },
    periods.map(([k, label]) =>
      el('button', { dataset: { k }, onclick: () => show(k) }, label)),
  );

  const card = el('section', { class: 'hero-card' },
    el('div', { class: 'row between', style: 'margin-bottom:14px' },
      el('span', { class: 'label' }, 'You keep'),
      seg,
    ),
    keep,
    el('div', { class: 'hero-row' },
      el('div', {}, lessons, el('span', {}, 'lessons')),
      el('div', {}, income, el('span', {}, 'income')),
    ),
  );
  show('week');
  return card;
}

/* ------------------------------ earnings chart ----------------------------- */

function niceMax(v) {
  if (v <= 0) return 100;
  const pow = Math.pow(10, Math.floor(Math.log10(v)));
  for (const m of [1, 2, 2.5, 5, 10]) if (m * pow >= v) return m * pow;
  return 10 * pow;
}

function chartCard() {
  const year = new Date().getFullYear();
  const data = monthlySeries(year);
  const maxIncome = niceMax(Math.max(...data.map(d => d.income)));

  const W = 720, H = 250, PAD_L = 56, PAD_R = 10, PAD_T = 26, PAD_B = 26;
  const plotW = W - PAD_L - PAD_R, plotH = H - PAD_T - PAD_B;
  const slotW = plotW / 12;
  const barW = Math.min(34, slotW * 0.58);
  const y = v => PAD_T + plotH - (v / maxIncome) * plotH;

  const NS = 'http://www.w3.org/2000/svg';
  const svg = document.createElementNS(NS, 'svg');
  svg.setAttribute('viewBox', `0 0 ${W} ${H}`);
  svg.setAttribute('class', 'chart-svg');
  svg.setAttribute('role', 'img');
  svg.setAttribute('aria-label', `Monthly earnings for ${year}: income split between your share and the pool's share`);

  const S = (tag, attrs) => {
    const n = document.createElementNS(NS, tag);
    for (const [k, v] of Object.entries(attrs)) n.setAttribute(k, v);
    return n;
  };

  const ticks = 4;
  for (let i = 0; i <= ticks; i++) {
    const v = (maxIncome / ticks) * i;
    const yy = y(v);
    svg.append(S('line', { x1: PAD_L, x2: W - PAD_R, y1: yy, y2: yy, class: i === 0 ? 'baseline' : 'grid-line', 'stroke-width': 1 }));
    if (i > 0) {
      const t = S('text', { x: PAD_L - 8, y: yy + 3.5, 'text-anchor': 'end', class: 'tick' });
      t.textContent = '£' + v.toLocaleString('en-GB');
      svg.append(t);
    }
  }

  const wrap = el('div', { class: 'chart-wrap' });
  const tip = el('div', { class: 'chart-tip' });

  data.forEach((d, i) => {
    const cx = PAD_L + slotW * i + slotW / 2;
    const g = S('g', { class: 'bar-group' });

    if (d.income > 0) {
      const keepH = (d.keep / maxIncome) * plotH;
      const pool = d.income - d.keep;
      const poolH = (pool / maxIncome) * plotH;
      const gap = pool > 0 ? 2 : 0;

      g.append(S('rect', {
        x: cx - barW / 2, y: y(d.keep), width: barW, height: Math.max(1, keepH),
        fill: C_KEEP, class: 'bar bar-anim', rx: pool > 0 ? 0 : 4,
      }));
      if (pool > 0) {
        g.append(S('rect', {
          x: cx - barW / 2, y: y(d.income), width: barW, height: Math.max(1, poolH - gap),
          fill: C_POOL, class: 'bar bar-anim', rx: 4,
        }));
      }
      const lbl = S('text', { x: cx, y: y(d.income) - 7, 'text-anchor': 'middle', class: 'bar-label' });
      lbl.textContent = '£' + d.income.toLocaleString('en-GB');
      g.append(lbl);
    }

    const hit = S('rect', { x: PAD_L + slotW * i, y: PAD_T, width: slotW, height: plotH, fill: 'transparent' });
    hit.addEventListener('mouseenter', () => {
      tip.innerHTML = `<b>${monthName(i)} ${year}</b><br>
        <span class="tl"><span class="swatch" style="background:${C_KEEP}"></span>You keep · ${fmtMoney(d.keep)}</span>
        <span class="tl"><span class="swatch" style="background:${C_POOL}"></span>Pool share · ${fmtMoney(d.income - d.keep)}</span>
        <span class="tl">Total · ${fmtMoney(d.income)} · ${d.lessons} lesson${d.lessons === 1 ? '' : 's'}</span>`;
      const r = wrap.getBoundingClientRect();
      tip.style.left = ((cx / W) * r.width) + 'px';
      tip.style.top = ((y(Math.max(d.income, 0)) / H) * r.width * (H / W)) + 'px';
      tip.classList.add('show');
    });
    hit.addEventListener('mouseleave', () => tip.classList.remove('show'));
    g.append(hit);

    const m = S('text', { x: cx, y: H - 8, 'text-anchor': 'middle', class: 'tick' });
    m.textContent = monthName(i).slice(0, 3);
    svg.append(g, m);
  });

  wrap.append(svg, tip);

  return el('section', { class: 'card' },
    cardHead('pulse', 'coral', String(year)),
    wrap,
    el('div', { class: 'chart-legend' },
      el('span', { class: 'k' }, el('span', { class: 'swatch', style: `background:${C_KEEP}` }), 'You keep'),
      el('span', { class: 'k' }, el('span', { class: 'swatch', style: `background:${C_POOL}` }), 'Pool share'),
    ),
  );
}

/* -------------------------------- side lists ------------------------------- */

function bookingRow(b) {
  const t = sessionType(b.type);
  return el('div', { class: 'list-row' },
    el('div', { class: 'date-chip' },
      el('div', { class: 'd' }, b.date.slice(8, 10)),
      el('div', { class: 'm' }, fmtDate(b.date, { month: 'short' })),
    ),
    el('div', { class: 'row-main' },
      el('div', { class: 'row-title' }, swimmerName(b.swimmerId)),
      el('div', { class: 'row-sub' }, `${b.time} · ${t ? t.label : b.type}`),
    ),
    el('div', { class: 'row-end' }, statusPill(b.status)),
  );
}

function cardHead(chipIcon, chipTint, title, endNode) {
  return el('div', { class: 'row between', style: 'margin-bottom:12px' },
    el('div', { class: 'row gap' },
      el('span', { class: 'title-chip ' + chipTint }, icon(chipIcon)),
      el('h2', { class: 'card-title', style: 'margin:0' }, title),
    ),
    endNode,
  );
}

function upcomingCard() {
  const items = upcomingBookings(3);
  if (!items.length) return null;
  return el('section', { class: 'card' },
    cardHead('calendar', 'blue', 'Coming up'),
    el('div', { class: 'list' }, items.map(bookingRow)),
  );
}

function owedCard() {
  const items = outstandingBookings();
  if (!items.length) return null;
  const total = items.reduce((a, b) => a + (b.price || 0), 0);
  return el('section', { class: 'card' },
    cardHead('wallet', 'amber', 'Unpaid', el('span', { class: 'pill pill-due' }, fmtMoney(total))),
    el('div', { class: 'list' }, items.map(bookingRow)),
  );
}

function blocksCard() {
  const active = state.blocks.filter(b => blockUsage(b.id).left > 0);
  if (!active.length) return null;
  return el('section', { class: 'card' },
    cardHead('ticket', 'aqua', 'Blocks'),
    el('div', { class: 'list' },
      active.map(b => {
        const u = blockUsage(b.id);
        return el('div', { class: 'list-row' },
          el('div', { class: 'row-main' },
            el('div', { class: 'row-title' }, swimmerName(b.swimmerId)),
            el('div', { class: 'row-sub' }, `${u.used} of ${u.total} used`),
          ),
          el('div', { class: 'row-end' },
            el('span', { class: 'pill ' + (u.left <= 1 ? 'pill-due' : 'pill-block') }, `${u.left} left`),
          ),
        );
      }),
    ),
  );
}
