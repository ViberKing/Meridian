// Harbour shell — hash router + swim-module navigation.
import { el } from './ui.js';
import { renderHome } from './views/home.js';
import { renderDashboard } from './views/dashboard.js';
import { renderCalendar } from './views/calendar.js';
import { renderBookings } from './views/bookings.js';
import { renderSwimmers } from './views/swimmers.js';
import { renderBlocks } from './views/blocks.js';
import { renderSettings } from './views/settings.js';

const app = document.getElementById('app');

const ICONS = {
  dashboard: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7.5" height="9" rx="2"/><rect x="13.5" y="3" width="7.5" height="5.5" rx="2"/><rect x="13.5" y="12" width="7.5" height="9" rx="2"/><rect x="3" y="15.5" width="7.5" height="5.5" rx="2"/></svg>',
  calendar: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="4.5" width="18" height="16" rx="3"/><path d="M3 9.5h18M8 2.5v4M16 2.5v4"/></svg>',
  bookings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><path d="M5 3.5h11.5A2.5 2.5 0 0 1 19 6v14.5l-3.5-2.3-3.5 2.3-3.5-2.3L5 20.5V6a2.5 2.5 0 0 1 0-2.5z"/><path d="M9 8.5h6M9 12h4"/></svg>',
  swimmers: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="7" r="3.5"/><path d="M3 20 q4.5 -4 9 0 t9 0"/></svg>',
  blocks: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="8.5"/><path d="M12 12 V5.5 A6.5 6.5 0 0 1 18.2 9.9 Z" fill="currentColor" stroke="none" opacity="0.45"/></svg>',
  settings: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.9" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3.2"/><path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06a1.7 1.7 0 0 0-1.87-.34 1.7 1.7 0 0 0-1.03 1.56V21a2 2 0 1 1-4 0v-.09a1.7 1.7 0 0 0-1.11-1.56 1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06a1.7 1.7 0 0 0 .34-1.87 1.7 1.7 0 0 0-1.56-1.03H3a2 2 0 1 1 0-4h.09a1.7 1.7 0 0 0 1.56-1.11 1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06a1.7 1.7 0 0 0 1.87.34h.09a1.7 1.7 0 0 0 1.03-1.56V3a2 2 0 1 1 4 0v.09a1.7 1.7 0 0 0 1.03 1.56 1.7 1.7 0 0 0 1.87-.34l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06a1.7 1.7 0 0 0-.34 1.87v.09a1.7 1.7 0 0 0 1.56 1.03H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.51 1.02z"/></svg>',
};

const SWIM_TABS = [
  { path: '#/swim',          label: 'Dashboard', icon: 'dashboard', render: renderDashboard },
  { path: '#/swim/calendar', label: 'Calendar',  icon: 'calendar',  render: renderCalendar },
  { path: '#/swim/bookings', label: 'Bookings',  icon: 'bookings',  render: renderBookings },
  { path: '#/swim/swimmers', label: 'Swimmers',  icon: 'swimmers',  render: renderSwimmers },
  { path: '#/swim/blocks',   label: 'Blocks',    icon: 'blocks',    render: renderBlocks },
  { path: '#/swim/settings', label: 'Settings',  icon: 'settings',  render: renderSettings },
];

function swimNav(activePath) {
  return el('nav', { class: 'nav', 'aria-label': 'Swim coaching sections' },
    SWIM_TABS.map(t =>
      el('a', {
        class: 'nav-item' + (t.path === activePath ? ' active' : ''),
        href: t.path,
        'aria-current': t.path === activePath ? 'page' : false,
      },
        el('span', { class: 'icon', html: ICONS[t.icon], 'aria-hidden': 'true' }),
        t.label,
      )
    )
  );
}

export function navigate(hash) {
  if (location.hash === hash) render();
  else location.hash = hash;
}

function render() {
  const hash = location.hash || '#/';
  app.querySelectorAll('.page, .nav, .fab').forEach(n => n.remove());
  document.body.classList.remove('with-nav');

  if (hash === '#/' || hash === '') {
    app.append(renderHome());
    window.scrollTo(0, 0);
    return;
  }

  const tab = SWIM_TABS.find(t => t.path === hash) || SWIM_TABS[0];
  document.body.classList.add('with-nav');
  app.append(swimNav(tab.path), tab.render());
  window.scrollTo(0, 0);
}

window.addEventListener('hashchange', render);
render();
