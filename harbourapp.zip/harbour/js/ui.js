// Small DOM + interaction helpers shared by every view.
import { icon } from './icons.js';

export function el(tag, attrs = {}, ...children) {
  const node = document.createElement(tag);
  for (const [k, v] of Object.entries(attrs)) {
    if (k === 'class') node.className = v;
    else if (k === 'html') node.innerHTML = v;
    else if (k.startsWith('on') && typeof v === 'function') node.addEventListener(k.slice(2), v);
    else if (k === 'dataset') Object.assign(node.dataset, v);
    else if (v === true) node.setAttribute(k, '');
    else if (v !== false && v != null) node.setAttribute(k, v);
  }
  for (const c of children.flat(Infinity)) {
    if (c == null || c === false) continue;
    node.append(c.nodeType ? c : document.createTextNode(c));
  }
  return node;
}

export function esc(s) {
  return String(s ?? '').replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

export const reducedMotion = () =>
  window.matchMedia('(prefers-reduced-motion: reduce)').matches;

/* ------------------------------- count-up ---------------------------------- */

export function countUp(node, target, format = v => v, duration = 700) {
  if (reducedMotion() || !Number.isFinite(target)) { node.textContent = format(target); return; }
  const start = performance.now();
  const from = 0;
  function tick(now) {
    const t = Math.min(1, (now - start) / duration);
    const eased = 1 - Math.pow(1 - t, 3);
    node.textContent = format(from + (target - from) * eased);
    if (t < 1) requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);
}

/* --------------------------------- toast ----------------------------------- */

let toastTimer = null;
export function toast(msg) {
  let t = document.querySelector('.toast');
  if (!t) {
    t = el('div', { class: 'toast', role: 'status' });
    document.body.append(t);
  }
  t.textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 2400);
}

/* --------------------------------- sheet ----------------------------------- */
// Bottom sheet on mobile, centred dialog on desktop. Returns a close function.

export function openSheet(title, contentNode, { onClose } = {}) {
  const backdrop = el('div', { class: 'sheet-backdrop' });
  const sheet = el('div', { class: 'sheet', role: 'dialog', 'aria-modal': 'true', 'aria-label': title },
    el('div', { class: 'sheet-grab' }),
    el('div', { class: 'sheet-head' },
      el('h2', { class: 'sheet-title' }, title),
      el('button', { class: 'icon-btn', 'aria-label': 'Close', onclick: () => close() }, icon('close')),
    ),
    el('div', { class: 'sheet-body' }, contentNode),
  );
  backdrop.append(sheet);
  document.body.append(backdrop);
  document.body.style.overflow = 'hidden';
  requestAnimationFrame(() => backdrop.classList.add('open'));

  function close() {
    backdrop.classList.remove('open');
    document.body.style.overflow = '';
    const done = () => { backdrop.remove(); onClose && onClose(); };
    reducedMotion() ? done() : setTimeout(done, 220);
  }
  backdrop.addEventListener('click', e => { if (e.target === backdrop) close(); });
  const onKey = e => { if (e.key === 'Escape') { close(); document.removeEventListener('keydown', onKey); } };
  document.addEventListener('keydown', onKey);
  return close;
}

export function confirmSheet(title, message, confirmLabel = 'Delete') {
  return new Promise(resolve => {
    const body = el('div', {},
      el('p', { class: 'muted', style: 'margin:0 0 20px' }, message),
      el('div', { class: 'row gap' },
        el('button', { class: 'btn ghost grow', onclick: () => { close(); resolve(false); } }, 'Cancel'),
        el('button', { class: 'btn danger grow', onclick: () => { close(); resolve(true); } }, confirmLabel),
      ),
    );
    const close = openSheet(title, body, { onClose: () => resolve(false) });
  });
}

/* --------------------------------- forms ----------------------------------- */

export function field(labelText, inputNode, hint) {
  return el('label', { class: 'field' },
    el('span', { class: 'field-label' }, labelText),
    inputNode,
    hint ? el('span', { class: 'field-hint' }, hint) : null,
  );
}

export function select(options, value, attrs = {}) {
  const s = el('select', { class: 'input', ...attrs });
  for (const o of options) {
    const opt = el('option', { value: o.value }, o.label);
    if (o.value === value) opt.selected = true;
    s.append(opt);
  }
  return s;
}

/* --------------------------------- misc ------------------------------------ */

export function initials(name) {
  return String(name).trim().split(/\s+/).slice(0, 2).map(w => w[0]).join('').toUpperCase();
}

export function statusPill(status) {
  const map = {
    paid:      ['Paid', 'pill-paid'],
    due:       ['Due', 'pill-due'],
    block:     ['Block', 'pill-block'],
    free:      ['Free', 'pill-free'],
    cancelled: ['Cancelled', 'pill-cancelled'],
  };
  const [label, cls] = map[status] || [status, 'pill-free'];
  return el('span', { class: 'pill ' + cls }, label);
}

export function staggerIn(container) {
  if (reducedMotion()) return;
  [...container.children].forEach((c, i) => {
    c.style.animationDelay = Math.min(i * 45, 400) + 'ms';
    c.classList.add('enter');
  });
}
